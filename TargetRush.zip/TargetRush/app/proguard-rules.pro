# Add project specific ProGuard rules here.
# Google Mobile Ads SDK ships its own consumer rules, no extra keep rules
# are required for typical usage.
