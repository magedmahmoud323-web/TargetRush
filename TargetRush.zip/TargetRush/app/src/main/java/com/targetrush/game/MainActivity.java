package com.targetrush.game;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

/**
 * Hosts the Target Rush HTML/JS game inside a WebView and bridges it to
 * native AdMob (Google Mobile Ads SDK) ads through window.AndroidAdsBridge,
 * matching the contract the game's own AdsManager JS module expects:
 *   loadRewarded() / showRewarded()
 *   loadInterstitial() / showInterstitial()
 *   showBanner(unitId) / hideBanner()
 * and the JS-side callbacks it calls back into:
 *   window.onAdMobRewardEarned()
 *   window.onAdMobAdClosed()
 *   window.onAdMobAdFailed(reason)
 */
public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private FrameLayout bannerContainer;
    private AdView bannerAdView;

    private InterstitialAd interstitialAd;
    private RewardedAd rewardedAd;
    private boolean rewardEarnedThisShow = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);
        bannerContainer = findViewById(R.id.bannerContainer);

        MobileAds.initialize(this, initializationStatus -> {
            // Preload both ad types as soon as the SDK is ready so they
            // are likely available the first time the game asks for them.
            loadInterstitialAd();
            loadRewardedAd();
        });

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true); // required for localStorage (save data)
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setCacheMode(android.webkit.WebSettings.LOAD_DEFAULT);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AdsBridge(), "AndroidAdsBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onDestroy() {
        if (bannerAdView != null) bannerAdView.destroy();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        if (bannerAdView != null) bannerAdView.pause();
        webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
        if (bannerAdView != null) bannerAdView.resume();
    }

    private void runJs(String js) {
        runOnUiThread(() -> webView.evaluateJavascript(js, null));
    }

    // ------------------------------------------------------------------
    // Interstitial
    // ------------------------------------------------------------------
    private void loadInterstitialAd() {
        AdRequest request = new AdRequest.Builder().build();
        InterstitialAd.load(this, AdsConfig.interstitialAdUnitId(), request,
                new InterstitialAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd ad) {
                        interstitialAd = ad;
                        interstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                            @Override
                            public void onAdDismissedFullScreenContent() {
                                interstitialAd = null;
                                loadInterstitialAd();
                                runJs("window.onAdMobAdClosed && window.onAdMobAdClosed();");
                            }

                            @Override
                            public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                                interstitialAd = null;
                                loadInterstitialAd();
                                runJs("window.onAdMobAdFailed && window.onAdMobAdFailed('show_failed');");
                            }
                        });
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        interstitialAd = null;
                    }
                });
    }

    // ------------------------------------------------------------------
    // Rewarded
    // ------------------------------------------------------------------
    private void loadRewardedAd() {
        AdRequest request = new AdRequest.Builder().build();
        RewardedAd.load(this, AdsConfig.rewardedAdUnitId(), request,
                new RewardedAdLoadCallback() {
                    @Override
                    public void onAdLoaded(@NonNull RewardedAd ad) {
                        rewardedAd = ad;
                        rewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                            @Override
                            public void onAdDismissedFullScreenContent() {
                                rewardedAd = null;
                                loadRewardedAd();
                                runJs("window.onAdMobAdClosed && window.onAdMobAdClosed();");
                            }

                            @Override
                            public void onAdFailedToShowFullScreenContent(@NonNull AdError adError) {
                                rewardedAd = null;
                                loadRewardedAd();
                                runJs("window.onAdMobAdFailed && window.onAdMobAdFailed('show_failed');");
                            }
                        });
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                        rewardedAd = null;
                    }
                });
    }

    // ------------------------------------------------------------------
    // JS <-> Native bridge
    // ------------------------------------------------------------------
    private class AdsBridge {

        @JavascriptInterface
        public void loadRewarded(String unusedUnitId) {
            runOnUiThread(() -> { if (rewardedAd == null) loadRewardedAd(); });
        }

        @JavascriptInterface
        public void showRewarded() {
            runOnUiThread(() -> {
                if (rewardedAd == null) {
                    // Not ready — tell JS immediately so it doesn't hang waiting.
                    runJs("window.onAdMobAdFailed && window.onAdMobAdFailed('not_loaded');");
                    loadRewardedAd();
                    return;
                }
                rewardEarnedThisShow = false;
                rewardedAd.show(MainActivity.this, rewardItem -> {
                    // Reward only ever granted here, after genuine completion.
                    rewardEarnedThisShow = true;
                    runJs("window.onAdMobRewardEarned && window.onAdMobRewardEarned();");
                });
            });
        }

        @JavascriptInterface
        public void loadInterstitial(String unusedUnitId) {
            runOnUiThread(() -> { if (interstitialAd == null) loadInterstitialAd(); });
        }

        @JavascriptInterface
        public void showInterstitial() {
            runOnUiThread(() -> {
                if (interstitialAd == null) {
                    runJs("window.onAdMobAdFailed && window.onAdMobAdFailed('not_loaded');");
                    loadInterstitialAd();
                    return;
                }
                interstitialAd.show(MainActivity.this);
            });
        }

        @JavascriptInterface
        public void showBanner(String unusedUnitId) {
            runOnUiThread(() -> {
                if (bannerAdView == null) {
                    bannerAdView = new AdView(MainActivity.this);
                    bannerAdView.setAdSize(AdSize.BANNER);
                    bannerAdView.setAdUnitId(AdsConfig.bannerAdUnitId());
                    bannerContainer.addView(bannerAdView, new ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                    bannerAdView.loadAd(new AdRequest.Builder().build());
                }
                bannerContainer.setVisibility(android.view.View.VISIBLE);
            });
        }

        @JavascriptInterface
        public void hideBanner() {
            runOnUiThread(() -> bannerContainer.setVisibility(android.view.View.GONE));
        }
    }
}
