package com.targetrush.game;

/**
 * Single place for all AdMob IDs. Nothing else in the app should
 * reference an ad unit ID string directly — always go through here.
 *
 * BuildConfig.TEST_ADS is wired in app/build.gradle: debug builds are
 * always TEST_ADS = true (Google's official test IDs), release builds
 * are TEST_ADS = false (your real AdMob IDs below). This means normal
 * "Run" / "Debug" from the IDE never serves real ads, and you don't have
 * to remember to change anything by hand before testing.
 */
public final class AdsConfig {

    private AdsConfig() {}

    public static boolean isTestMode() {
        return BuildConfig.TEST_ADS;
    }

    // ---- Your real production AdMob IDs (used only in release builds) ----
    private static final String PROD_BANNER_ID        = "ca-app-pub-3929816871255283/6156878021";
    private static final String PROD_INTERSTITIAL_ID  = "ca-app-pub-3929816871255283/8731070479";
    private static final String PROD_REWARDED_ID      = "ca-app-pub-3929816871255283/4791825468";

    // ---- Official Google test ad unit IDs (safe to ship in debug builds) ----
    private static final String TEST_BANNER_ID        = "ca-app-pub-3940256099942544/6300978111";
    private static final String TEST_INTERSTITIAL_ID  = "ca-app-pub-3940256099942544/1033173712";
    private static final String TEST_REWARDED_ID      = "ca-app-pub-3940256099942544/5224354917";

    public static String bannerAdUnitId() {
        return isTestMode() ? TEST_BANNER_ID : PROD_BANNER_ID;
    }

    public static String interstitialAdUnitId() {
        return isTestMode() ? TEST_INTERSTITIAL_ID : PROD_INTERSTITIAL_ID;
    }

    public static String rewardedAdUnitId() {
        return isTestMode() ? TEST_REWARDED_ID : PROD_REWARDED_ID;
    }
}
